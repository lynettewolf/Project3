﻿/*Map.cs
 * Created By: Juliette Corpstein
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ksu.Cis300.MapViewer
{
    public partial class Map : UserControl
    {
        public Map()
        {
            InitializeComponent();
        }
        
        /// <summary>
        /// Constant holding the max zoom levels at 6
        /// </summary>
        private const int maxZoom = 6;

        /// <summary>
        /// current scale factor
        /// </summary>
        private int _scale;

        /// <summary>
        /// Will store the current zoom level
        /// </summary>
        private int _zoom = 0;

        /// <summary>
        /// Will contain map data
        /// </summary>
        private QuadTree _qtree;

        /// <summary>
        /// Will return a boolean value indicating whether the point is within the triangle
        /// </summary>
        /// <param name="p">the PointF that is eather in or out of the rectangle</param>
        /// <param name="r">the RectangleF that the point is concidered to be in</param>
        /// <returns></returns>
        private static bool IsWithinBounds(PointF p, RectangleF r)
        {
            return  p.X <= r.Right && p.X >= r.Left && p.Y >= r.Top && p.Y <= r.Bottom;
        }


        /// <summary>
        /// A constructor for the map
        /// </summary>
        /// <param name="streets">a list of street segments </param>
        /// <param name="bounds">the bounds of the rectangle</param>
        /// <param name="scale">the scale factor</param>
        public Map(List<StreetSegment> streets, RectangleF bounds, int scale)
        {
           
            
            int i = 0;
            foreach (StreetSegment ss in streets)
            {

                if (!IsWithinBounds(ss.Start, bounds) || !IsWithinBounds(ss.End, bounds))
                {
                    throw new ArgumentException("Street " + i + "is not within the given bounds");

                }
                i++;
            }
            InitializeComponent();
            _qtree = new QuadTree(streets, bounds, maxZoom);

            _scale = scale;

            Size = new Size((int)(scale * bounds.Width), (int)(scale * bounds.Height));

        }

        /// <summary>
        /// A boolean valuse that will check to see if you zoom in or not
        /// </summary>
        /// <returns>Whether you can zoom in bool value</returns>
        public bool CanZoomIn
        {

            get
            {
                                
                if (_zoom < maxZoom )
                    return true;
                else
                    return false;
                   
            }
        }

        /// <summary>
        /// Determine whether you can zoom out or not
        /// </summary>
        /// <returns>Boolean value that refelcts whether you can zoom  out or not</returns>
        public bool CanZoomOut
        {
        get
        {
               
               
            if (_zoom > 0 )
                return true;
            else
                return false;
                
        }
        }


        /// <summary>
        /// Will change all values so it refelct the zoom level if possible
        /// </summary>
        public void ZoomIn()
        {
            if (CanZoomIn)
            {
                _scale = _scale * 2;
                _zoom = _zoom + 1;
               

                int sh = Size.Height;
                int sw = Size.Width;

                int nh = sh * 2;
                int nw = sw * 2;

                Size = new Size(nw, nh);
                Invalidate();
            }
                

            
        }

        /// <summary>
        /// Will change all fields to reflect the zoom out if possible
        /// </summary>
        public void ZoomOut()
        {
            if (CanZoomOut)
            {
                _scale = _scale / 2;
                _zoom = _zoom - 1;
                
                int sh = Size.Height;
                int sw = Size.Width;

                int nh = sh / 2;
                int nw = sw / 2;

                Size = new Size(nw, nh);

                Invalidate();
            }
            
        }

        /// <summary>
        /// Called whenever the map needs to be redrawn, will redraw the map
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            RectangleF rec = e.ClipRectangle;

            e.Graphics.Clip = new Region(rec);

            _qtree.Draw(e.Graphics, _scale, _zoom);

        }


    }//end

}
