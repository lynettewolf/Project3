﻿/* StreertSegment.cs
 * Created By: Juliette Corpstien
 */

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Ksu.Cis300.MapViewer
{
    public struct StreetSegment
    {
        
        /// <summary>
        /// A point consisting of two floating-point cordnates giving the starting point of the segment.
        /// </summary>
        private PointF _start;

        /// <summary>
        /// A point consisting of two floating point cordnates giving the ending point. 
        /// </summary>
        private PointF _end;

        /// <summary>
        /// A pen giving the color adn width off the segment
        /// </summary>
        private Pen _pen;

        /// <summary>
        /// The number of zoom levels at which this segment is visible
        /// </summary>
        private int _visibleLevels;


       /// <summary>
       /// A constructor to get the value of _start or set the value of _start
       /// </summary>
       public PointF Start
       {
            get
            {
                return _start;
            }
            set
            {
                _start = value;
            }
       }


       /// <summary>
       /// A constructor to get the value or _end or set the value of _end
       /// </summary>
       public PointF End
        {
            get
            {
                return _end;
            }
            set
            {
                _end = value;
            }
        }


      /// <summary>
      /// A constructor that will only get the visible zoom levels
      /// </summary>
      public int VisibleLevels
        {
            get
            {
                return _visibleLevels;
            }
        }


        /// <summary>
        /// A constructor that will set all parameters.
        /// </summary>
        /// <param name="start">the PointF with startign cordanates</param>
        /// <param name="end">The pointF with ending cordinates</param>
        /// <param name="color">the color of the line beign drawn</param>
        /// <param name="width">the width of the line being drawn</param>
        /// <param name="zoom">the number of zoom levels the segment is visible</param>
        public StreetSegment(PointF start, PointF end, Color color, float width, int zoom)
        {
            _start = start;
            _end = end;
            _visibleLevels = zoom;
            _pen = new Pen(color, width);
        }


       /// <summary>
       /// Will draw a a line on the graphic board with the given pen and points
       /// </summary>
       /// <param name="g">the graphic board on which to draw</param>
       /// <param name="scaleFactor">the scale which the points need to be converted 
       /// from map cornanates to pixel cordanates</param>
       public void Draw(Graphics g, int scaleFactor)
        {
            float startX = _start.X * scaleFactor;
            float startY = _start.Y * scaleFactor;
            float endX = _end.X * scaleFactor;
            float endY = _end.Y * scaleFactor;

            g.DrawLine(_pen, startX , startY, endX, endY);
        }

    }//end struct
}
