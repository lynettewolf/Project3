﻿/* UserInterface.cs
 * Created By: Juliette Corpstein
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Ksu.Cis300.MapViewer
{
    public partial class UserInterface : Form
    {
        public UserInterface()
        {
            InitializeComponent();
        }


        /// <summary>
        /// Constant to store the scale factor at minimum zoom
        /// </summary>
        private const int  _scaleMinZoom = 10;

        /// <summary>
        /// Store the current map
        /// </summary>
        private Map _map;

        

        

        /// <summary>
        /// Will Read in the File and handle creating all of the street segments and the list
        /// </summary>
        /// <param name="fileName">the name of the file that needs to be read in </param>
        /// <param name="bounds">Will modify the rectangef that was passed in giving it new height and width</param>
        /// <returns>Will return a list of the the street segments that we read form the file</returns>
        private static List<StreetSegment> ReadFile(string fileName, out RectangleF bounds)
        {
            using( StreamReader sr = new StreamReader(fileName))
            {
                string w = sr.ReadLine();
                string[] ws = w.Split(',');

                float mwm = Convert.ToSingle(ws[0]);
                float mhm = Convert.ToSingle(ws[1]);

                bounds = new RectangleF(0,0,mwm, mhm);
                
                List<StreetSegment> lss = new List<StreetSegment>();

                while (!sr.EndOfStream)
                {
                    string line = sr.ReadLine();
                    string[] lsplit = line.Split(',');

                    float xs = Convert.ToSingle(lsplit[0]);
                    float ys = Convert.ToSingle(lsplit[1]);
                    float xe = Convert.ToSingle(lsplit[2]);
                    float ye = Convert.ToSingle(lsplit[3]);

                    PointF start = new PointF(xs, ys);
                    PointF end = new PointF(xe, ye);
                    Color c = Color.FromArgb(Convert.ToInt32(lsplit[4]));

                    float pixWidth = Convert.ToSingle(lsplit[5]);

                    int zoom = Convert.ToInt32(lsplit[6]);

                    StreetSegment ss = new StreetSegment(start, end, c, pixWidth, zoom);

                    lss.Add(ss);
                }
                return lss;
            }

        }


        /// <summary>
        /// handels the opening on the map chick, will read in file and fill a initial list containinag all in file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxOpenMap_Click(object sender, EventArgs e)
        {

           
                if (uxOpenDialog.ShowDialog() == DialogResult.OK)
                {
                try
                {
                    string fn = uxOpenDialog.FileName;
                    RectangleF bounds;

                    List<StreetSegment> lss = ReadFile(fn, out bounds);

                    _map = new Map(lss, bounds, _scaleMinZoom);

                    uxMapContainer.Controls.Clear();
                    uxMapContainer.Controls.Add(_map);
                   
                    uxZoomIn.Enabled = true;
                    uxZoomOut.Enabled = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("ERROR " + ex);
                }
            }
            

        }

        /// <summary>
        /// Will handle zooming in and redrawing the map
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxZoomIn_Click(object sender, EventArgs e)
        {

           Point scrollLoc = uxMapContainer.AutoScrollPosition;
            scrollLoc = new Point(-scrollLoc.X, -scrollLoc.Y);

            _map.ZoomIn();
            uxZoomOut.Enabled = true;

            uxZoomIn.Enabled = _map.CanZoomIn;
            
            Size cs = uxMapContainer.ClientSize;

            int xv = (scrollLoc.X * 2) + (int)(.5 * cs.Width);
            int yv = (scrollLoc.Y * 2) + (int)(.5 * cs.Height);

            scrollLoc = new Point(xv, yv);
            uxMapContainer.AutoScrollPosition = scrollLoc;

        }



        /// <summary>
        /// Will handel the zoom out and redrawing of the map
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxZoomOut_Click(object sender, EventArgs e)
        {

            Point scrollLoc = uxMapContainer.AutoScrollPosition;
            scrollLoc = new Point(-scrollLoc.X, -scrollLoc.Y);

            _map.ZoomOut();
            uxZoomIn.Enabled = true;

            uxZoomOut.Enabled = _map.CanZoomOut;
           
            Size cs = uxMapContainer.ClientSize;

            int xv = (scrollLoc.X / 2) - ((1 / 4) * cs.Width);
            int yv = (scrollLoc.Y / 2) - ((1 / 4) * cs.Height);

            scrollLoc = new Point(xv, yv);
            uxMapContainer.AutoScrollPosition = scrollLoc;

            
        }
    }// end class
}
