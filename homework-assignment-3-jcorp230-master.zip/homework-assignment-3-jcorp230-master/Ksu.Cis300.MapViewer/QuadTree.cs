﻿/* QuadTree.cs
 * Created By: Juliette Corpstein
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Ksu.Cis300.MapViewer
{
    class QuadTree
    {

        /// <summary>
        /// store children of southeast
        /// </summary>
        private QuadTree _southeastChild;

        /// <summary>
        /// store children of southwest
        /// </summary>
        private QuadTree _southwestChild;

       /// <summary>
       /// stores child of northwest
       /// </summary>
       private QuadTree _northwestChild;

        /// <summary>
        /// stores child of northeast
        /// </summary>
        private QuadTree _northeastChild;


        /// <summary>
        /// A rectangle in map cordanates that the node represents
        /// </summary>
        private RectangleF _bounds;

        /// <summary>
        /// A List contaning the street segments associated with this node.
        /// </summary>
        private List<StreetSegment> _streets;

        /// <summary>
        /// Will split the strees into segments of vissible anf invissible streets
        /// </summary>
        /// <param name="split">the list of street segments to split</param>
        /// <param name="heightcurr">the current height/zoom level</param>
        /// <param name="visibleStreets">the list of visible streets</param>
        /// <param name="invisibleStreets">the list of invissible streets</param>
        private static void SplitHeight(List<StreetSegment> split, int heightcurr, List<StreetSegment> visibleStreets, List<StreetSegment> invisibleStreets)
        {

            foreach(StreetSegment ss in split)
            {
                if(ss.VisibleLevels > heightcurr)
                {
                    visibleStreets.Add(ss);
                }
                else
                {
                    invisibleStreets.Add(ss);
                }
            }

        }


        /// <summary>
        /// Will split the street segments into a east and west potion
        /// </summary>
        /// <param name="split">The List of street segments to be split</param>
        /// <param name="west">The list of street segments west or right of the given x</param>
        /// <param name="east">The list of street segments to the east/right of the given x</param>
        /// <param name="verticalX">The x value that we are going to be splitting at</param>
        private static void SplitEastWest(List<StreetSegment> split, float verticalX, List<StreetSegment> west, List<StreetSegment> east)
        {

            foreach(StreetSegment ss in split)
            {
                if(ss.Start.X <= verticalX && ss.End.X <= verticalX)
                {
                    west.Add(ss);
                }
                else if(ss.Start.X >= verticalX && ss.End.X >= verticalX)
                {
                    east.Add(ss);
                }
                else
                {
                    StreetSegment less = ss;
                    StreetSegment greater = ss;

                    float y = (ss.End.Y - ss.Start.Y) / (ss.End.X - ss.Start.X) * (verticalX - ss.Start.X) + ss.Start.Y;


                    PointF temp = new PointF(verticalX, y);
                    less.End = temp;
                    greater.Start = temp;

                     if(ss.Start.X <= verticalX)
                    {
                        west.Add(less);
                        east.Add(greater);

                    }
                     else
                    {
                        east.Add(less);
                        west.Add(greater);
                    }


                }
            }
        }


        /// <summary>
        /// Will split list of street segments north adn south of given y value.
        /// </summary>
        /// <param name="split">The list to split</param>
        /// <param name="horizontalY">the y value which to spit at</param>
        /// <param name="north">The List to add the street segments north/above the y</param>
        /// <param name="south">The List to add teh street segments south/bellow the y</param>
        private static void SplitNorthSouth(List<StreetSegment> split, float horizontalY, List<StreetSegment> north, List<StreetSegment> south)
        {

            foreach(StreetSegment ss in split)
            {
                if(ss.Start.Y <= horizontalY && ss.End.Y <= horizontalY)
                {
                    north.Add(ss);
                }
                else if(ss.Start.Y >= horizontalY && ss.End.Y >= horizontalY)
                {
                    south.Add(ss);
                }
                else
                {
                    StreetSegment less = ss;
                    StreetSegment greater = ss;

                    
                    float x = (ss.End.X - ss.Start.X) /  (ss.End.Y - ss.Start.Y) * (horizontalY - ss.Start.Y) + ss.Start.X;


                    PointF temp = new PointF(x, horizontalY);

                    less.End = temp;
                    greater.Start = temp;
                   
                    if (ss.Start.Y <= horizontalY)
                    {
                        north.Add(less);
                        south.Add(greater);

                    }
                    else
                    {
                        north.Add(greater);
                        south.Add(less);
                    }
                }
                    
            }

        }


        /// <summary>
        /// Will initalize each node of streets and all of there children, is a recursive method
        /// </summary>
        /// <param name="lss">The inital list that you are starting with the node</param>
        /// <param name="bounds">the new bounds that the children are going to occupy</param>
        /// <param name="height">the current height of the node</param>
        public QuadTree(List<StreetSegment> lss, RectangleF bounds, int height)
        {
            
            _bounds = bounds;
            
            if (height == 0)
            {
               _streets = lss;
               
            }
            else
            {
                float xv = ((bounds.Width / 2) + bounds.Left);
                float yv = ((bounds.Height / 2) + bounds.Top);


                List<StreetSegment> invissible = new List<StreetSegment>();
                _streets = new List<StreetSegment>();

                SplitHeight(lss, height, _streets, invissible);

                

                
                List<StreetSegment> north = new List<StreetSegment>();
                List<StreetSegment> south = new List<StreetSegment>();
                SplitNorthSouth(lss, yv, north, south);


                List<StreetSegment> northWest = new List<StreetSegment>();
                List<StreetSegment> northEast = new List<StreetSegment>();
                List<StreetSegment> southEast = new List<StreetSegment>();
                List<StreetSegment> southWest = new List<StreetSegment>();

                SplitEastWest(north, xv, northWest, northEast);
                SplitEastWest(south, xv, southWest, southEast);

                int childHeight = height - 1;
                float boundsHalfWidth = bounds.Width / 2;
                float boundsHalfHeight = bounds.Height / 2;
                float midy = bounds.Top + boundsHalfHeight;
                float midx = bounds.Left + boundsHalfWidth;

                
                RectangleF northWestB = new RectangleF(bounds.Left, bounds.Top ,boundsHalfWidth, boundsHalfHeight );
                RectangleF northEastB = new RectangleF(midx, bounds.Top, boundsHalfWidth, boundsHalfHeight);
                RectangleF southWestB = new RectangleF(bounds.Left, midy, boundsHalfWidth, boundsHalfHeight);
                RectangleF southEastB = new RectangleF(midx , midy, boundsHalfWidth, boundsHalfHeight);


                _northwestChild = new QuadTree(northWest, northWestB, childHeight);
                _northeastChild = new QuadTree(northEast, northEastB, childHeight);
                              
                _southwestChild = new QuadTree(southWest, southWestB, childHeight);
                _southeastChild = new QuadTree(southEast, southEastB, childHeight);
                
               
            }

        }




        /// <summary>
        /// Will draw the current node all all children that are vissible. Is recurssive.
        /// </summary>
        /// <param name="g">the graphics to draw on</param>
        /// <param name="scale">the scale factor that the node needs to be drawn at</param>
        /// <param name="maxDepth">the depth of the heightes node to be drawn</param>
        public void Draw(Graphics g, int scale, int maxDepth)
        {

            RectangleF map = new RectangleF(g.ClipBounds.X / scale, g.ClipBounds.Y / scale, g.ClipBounds.Width / scale, g.ClipBounds.Height / scale);
          

            if(_bounds.IntersectsWith(map))
            {
                
                foreach(StreetSegment ss in _streets)
                {
                    ss.Draw(g, scale);
                }
                if(maxDepth > 0)
                {
                    int nd = maxDepth - 1;
                    _northwestChild.Draw(g, scale, nd);
                    _northeastChild.Draw(g, scale, nd);
                    _southeastChild.Draw(g, scale, nd);
                    _southwestChild.Draw(g, scale, nd);
                }
                                
            }

        }
    }//end class
}
